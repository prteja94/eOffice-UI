import { Columns } from 'ngx-easy-table';

export interface Tabledata {

}

export const columns: Columns[] = [

];

export const data: Tabledata[] = [
  
  {
    sno: 'Admin',
    actionName: 'Project A',
    actionNameAr: 'Construction',
    status: 'true',
    createdBy: 'Construction',
    updatedON: 'Construction',
  },
  {
    sno: 'Admin',
    actionName: 'Project A',
    actionNameAr: 'Construction',
    status: 'false',
    createdBy: 'Construction',
    updatedON: 'Construction',
  },


];