import { Columns } from 'ngx-easy-table';

export interface Tabledata {

}

export const columns: Columns[] = [

];

export const data: Tabledata[] = [
  

];