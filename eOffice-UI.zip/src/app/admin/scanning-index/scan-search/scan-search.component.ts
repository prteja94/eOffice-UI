import { Component } from '@angular/core';

@Component({
  selector: 'app-scan-search',
  templateUrl: './scan-search.component.html',
  styleUrls: ['./scan-search.component.scss']
})
export class ScanSearchComponent {

  
  selectedOption: string = 'option1';
  
}
