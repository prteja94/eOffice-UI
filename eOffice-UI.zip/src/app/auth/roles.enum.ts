export enum Roles {
  Admin = 'Admin',
  Scan = 'Scan',
  Circular = 'Circular',
}