import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-not-found',
  standalone: true,
  templateUrl: './not-found.component.html'
})
export class NotfoundComponent implements AfterViewInit {
  ngAfterViewInit() {}
}
