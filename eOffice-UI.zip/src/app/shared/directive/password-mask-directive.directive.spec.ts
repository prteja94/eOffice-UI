import { PasswordMaskDirectiveDirective } from './password-mask-directive.directive';

describe('PasswordMaskDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordMaskDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
