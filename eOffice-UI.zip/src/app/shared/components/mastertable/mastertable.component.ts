import { Component } from '@angular/core';

@Component({
  selector: 'app-mastertable',
  templateUrl: './mastertable.component.html',
  styleUrls: ['./mastertable.component.scss']
})
export class MastertableComponent {

}
