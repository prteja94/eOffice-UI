export const environment = {
  production: false,
  bypassAuthGuard: true, // Development flag to bypass AuthGuard
  name: 'dev',
  Dynamsoft: {
    resourcesPath: 'assets/dwt-resources',
    dwtProductKey: 't01898AUAAI66wvoyuMqp0hocuzfBPh1LaIWzlj6qtvYOgKis42SHP4pu/K1hZlPksHadQF/eseZK/8nZYUBGHLLKGOGX+mf2+OVkB6e2d6q0d6KDk7ecIs91OG+nHdZ9aQMj8FoBPa7DASAHtloK4D3stcED6AHqAOrVAA+4fIv641PKgOSr/xxocrKDU9s784C0caKDk7ecFpDRQvGx1WUDkN+cE0AP0EsA+4+sCoiUAD1AK8AKCDKG6Qs20ymi',
    uploadTargetURL: ''
  }
};
