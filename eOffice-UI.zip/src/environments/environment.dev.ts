export const environment = {
  production: false,
  bypassAuthGuard: false,
  name: 'dev',
};