export const environment = {
  production: true,
  bypassAuthGuard: false, // Ensure AuthGuard is active in production
  name: 'prod',
};